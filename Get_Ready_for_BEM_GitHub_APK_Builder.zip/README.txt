GET READY FOR BEM — ANDROID STUDIO SOURCE PROJECT

This ZIP contains the original website pages and an Android WebView wrapper.

HOW TO BUILD THE APK (FREE)
1. Install Android Studio on a computer (Windows 10/11, macOS or Linux).
2. Unzip this archive.
3. In Android Studio choose Open and select the Get_Ready_for_BEM_Android folder.
4. Allow Android Studio to download Gradle and Android SDK components (internet needed ONCE for building).
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The APK will be in app/build/outputs/apk/debug/app-debug.apk.
7. Copy the APK to your Android device and install it.

IMPORTANT LIMITATIONS
- No APK binary is included: the Android SDK/build tools are not available in this environment.
- This wrapper includes no INTERNET permission and loads the bundled local HTML pages offline.
- External fonts, images, videos, and remote scripts will not load offline unless replaced with bundled assets.
- Browser speechSynthesis audio is NOT guaranteed in Android WebView; the ZIP contains no mp3/wav/ogg files. Offline spoken audio must be tested and may require native Android TextToSpeech integration or bundled recordings.
- Some links that point to external sites or use absolute paths may not work offline.
- Test all pages and interactions on a physical phone before distribution.
